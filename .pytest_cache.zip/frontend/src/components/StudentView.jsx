import React, { useState, useEffect } from 'react';
import { Clock, Users, CheckCircle2, AlertCircle, ArrowRight, MapPin, Navigation, Phone, Mail, ChevronDown, ChevronUp, BookOpen, Search, QrCode } from 'lucide-react';
import CampusMap from './CampusMap';

export default function StudentView({
  stops,
  selectedStopId,
  onSelectStop,
  arrivalsData,
  vehicles,
  onCheckIn,
  hasCheckedIn,
  onOpenPayment
}) {
  const DEFAULT_VIT_DIRECTORY = {
    "stop-vit-mh-qrst": {
      "cluster_name": "MH Q, R, S, T High-Rise Blocks",
      "description": "Northern towers near Outdoor Stadium and Swimming Pool.",
      "blocks": [
        {"code": "MH Q", "name": "VAJPAYEE BLOCK", "phone": "0416 220 2548", "email": "mhqblock@vit.ac.in"},
        {"code": "MH R", "name": "MUTHAMIZH ARIGNAR KALAIGNAR M.KARUNANIDHI", "phone": "0416 220 2549", "email": "mhrblock@vit.ac.in"},
        {"code": "MH S", "name": "ABDUL KALAM BLOCK", "phone": "0416 220 2550", "email": "mhsblock@vit.ac.in"},
        {"code": "MH T", "name": "JAGADISH CHANDRA BOSE BLOCK", "phone": "0416 220 2551", "email": "mhtblock@vit.ac.in"}
      ]
    },
    "stop-vit-mh-ghjkl": {
      "cluster_name": "MH G, H, J, K, L Blocks (Darling Mess Hub)",
      "description": "Adjacent to Darling Special Mess, Food Mall and Nescafe.",
      "blocks": [
        {"code": "MH G", "name": "SOCRATES", "phone": "0416 220 2539", "email": "mhgblock@vit.ac.in"},
        {"code": "MH H", "name": "JOHN F KENNEDY", "phone": "0416 220 2540", "email": "mhhblock@vit.ac.in"},
        {"code": "MH J", "name": "JOHN F KENNEDY", "phone": "0416 220 2541", "email": "mhjblock@vit.ac.in"},
        {"code": "MH K", "name": "Dr. SARVEPALLI RADHAKRISHNAN", "phone": "0416 220 2542", "email": "mhkblock@vit.ac.in"},
        {"code": "MH L", "name": "NETAJI SUBHAS CHANDRA BOSE", "phone": "0416 220 2543", "email": "mhlblock@vit.ac.in"}
      ]
    },
    "stop-vit-mh-mnp": {
      "cluster_name": "MH M, N, P Blocks (Central Quad)",
      "description": "Central hostel walkway connecting to Outdoor Sports Stadium.",
      "blocks": [
        {"code": "MH M", "name": "QUAID-E- MILLAT MUHAMMED ISMAIL", "phone": "0416 220 2544", "email": "mhmblock@vit.ac.in"},
        {"code": "MH M ANNEX", "name": "QUAID-E- MILLAT - M ANNEX", "phone": "0416 220 2545", "email": "mhmannexblock@vit.ac.in"},
        {"code": "MH N", "name": "CHARLES DARWIN", "phone": "0416 220 2546", "email": "mhnblock@vit.ac.in"},
        {"code": "MH N ANNEX", "name": "CHARLES DARWIN - N ANNEX", "phone": "0416 220 2564", "email": "mhnannexblock@vit.ac.in"},
        {"code": "MH P", "name": "SARDAR PATEL", "phone": "0416 220 2547", "email": "mhpblock@vit.ac.in"}
      ]
    },
    "stop-vit-mh-abcdef": {
      "cluster_name": "MH A - F Blocks (West Hostel Zone)",
      "description": "Near Technology Tower, Anna Auditorium and Enzo.",
      "blocks": [
        {"code": "MH A", "name": "ALBERT EINSTEIN", "phone": "0416 220 2531", "email": "mhablock@vit.ac.in"},
        {"code": "MH B", "name": "SWAMI VIVEKANANDA", "phone": "0416 220 2532", "email": "mhbblock@vit.ac.in"},
        {"code": "MH B ANNEX", "name": "SWAMI VIVEKANANDA – B ANNEX", "phone": "0416 220 2533", "email": "mhbannex@vit.ac.in"},
        {"code": "MH C", "name": "RABINDRANATH TAGORE", "phone": "0416 220 2534", "email": "mhcblock@vit.ac.in"},
        {"code": "MH D", "name": "NELSON MANDELA", "phone": "0416 220 2535", "email": "mhdblock@vit.ac.in"},
        {"code": "MH D ANNEX", "name": "NELSON MANDELA – D ANNEX", "phone": "0416 220 2536", "email": "mhdannex@vit.ac.in"},
        {"code": "MH E", "name": "SIR C.V.RAMAN", "phone": "0416 220 2537", "email": "mheblock@vit.ac.in"},
        {"code": "MH F", "name": "RAMANUJAM", "phone": "0416 220 2538", "email": "mhfblock@vit.ac.in"}
      ]
    },
    "stop-vit-lh-abcdef": {
      "cluster_name": "LH A - F Blocks (Main Ladies Hostel & Food Park)",
      "description": "Main LH Quadrangle adjacent to Food Park & Tiruvallur statue.",
      "blocks": [
        {"code": "LH A", "name": "Ladies Hostel Block A", "phone": "0416 220 2669", "email": "lhablock@vit.ac.in"},
        {"code": "LH B", "name": "Ladies Hostel Block B", "phone": "0416 220 2670", "email": "lhbblock@vit.ac.in"},
        {"code": "LH C", "name": "Ladies Hostel Block C", "phone": "0416 220 2703", "email": "lhcblock@vit.ac.in"},
        {"code": "LH D", "name": "Ladies Hostel Block D", "phone": "0416 220 2704", "email": "lhdblock@vit.ac.in"},
        {"code": "LH E", "name": "Ladies Hostel Block E", "phone": "0416 220 2705", "email": "lheblock@vit.ac.in"},
        {"code": "LH F", "name": "Ladies Hostel Block F", "phone": "0416 220 2706", "email": "lhfblock@vit.ac.in"}
      ]
    },
    "stop-vit-lh-ghj": {
      "cluster_name": "LH G, H, J, RGT & GH Annex Towers",
      "description": "North Ladies Hostel towers with direct pathway to SJT & TT.",
      "blocks": [
        {"code": "LH G", "name": "Ladies Hostel Block G", "phone": "0416 220 2892", "email": "lhgblock@vit.ac.in"},
        {"code": "LH H", "name": "Ladies Hostel Block H", "phone": "0416 220 2894", "email": "lhhblock@vit.ac.in"},
        {"code": "LH J", "name": "Ladies Hostel Block J", "phone": "0416 220 2896", "email": "lhjblock@vit.ac.in"},
        {"code": "RGT H", "name": "RGT Hostel Block", "phone": "0416 220 5003", "email": "rgthblock@vit.ac.in"},
        {"code": "LH GH", "name": "LH GH (Annex)", "phone": "0416 220 2244", "email": "lhghannex@vit.ac.in"}
      ]
    }
  };

  const [destStopId, setDestStopId] = useState('stop-vit-tt');
  const [hostelDirectory, setHostelDirectory] = useState(DEFAULT_VIT_DIRECTORY);
  const [showFullDirectory, setShowFullDirectory] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch official VIT Hostel Directory from backend
  useEffect(() => {
    fetch('http://localhost:8000/api/stops/hostel-directory')
      .then(res => {
        if (!res.ok) throw new Error('Status ' + res.status);
        return res.json();
      })
      .then(data => {
        if (data && typeof data === 'object' && !data.detail) {
          setHostelDirectory(data);
        }
      })
      .catch(err => console.warn('Using bundled VIT hostel directory:', err.message));
  }, []);

  const selectedStop = stops.find(s => s.id === selectedStopId) || stops[0];
  const destStop = stops.find(s => s.id === destStopId) || stops[2] || stops[1];
  const primaryArrival = arrivalsData?.arrivals?.[0];
  const alternateArrival = arrivalsData?.arrivals?.find(a => a.is_alternate) || arrivalsData?.arrivals?.[1];

  // Current cluster metadata if selected stop is a hostel
  const activeDirectory = hostelDirectory || DEFAULT_VIT_DIRECTORY;
  const currentCluster = activeDirectory[selectedStopId] && Array.isArray(activeDirectory[selectedStopId].blocks)
    ? activeDirectory[selectedStopId]
    : null;

  // Inter-block distance calculation
  const calculateStopDistance = () => {
    if (!selectedStop || !destStop) return null;
    const R = 6371000;
    const phi1 = (selectedStop.latitude * Math.PI) / 180;
    const phi2 = (destStop.latitude * Math.PI) / 180;
    const dPhi = ((destStop.latitude - selectedStop.latitude) * Math.PI) / 180;
    const dLam = ((destStop.longitude - selectedStop.longitude) * Math.PI) / 180;
    const a = Math.sin(dPhi / 2) ** 2 + Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLam / 2) ** 2;
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distM = Math.round(R * c);
    return {
      meters: distM,
      formatted: distM < 1000 ? `${distM} meters` : `${(distM / 1000).toFixed(1)} km`,
      walkMins: Math.max(1, Math.round(distM / 75)), // ~4.5 km/h walking
      shuttleMins: Math.max(1, Math.round(distM / 280)) // ~17 km/h shuttle
    };
  };

  const journeyInfo = calculateStopDistance();

  const getBadgeClass = (category) => {
    switch (category) {
      case 'Available': return 'badge-available';
      case 'Filling': return 'badge-filling';
      case 'Nearly full': return 'badge-nearly-full';
      case 'Full': return 'badge-full';
      default: return 'badge-unknown';
    }
  };

  const getMeterColor = (category) => {
    switch (category) {
      case 'Available': return 'var(--status-available)';
      case 'Filling': return 'var(--status-filling)';
      case 'Nearly full': return 'var(--status-nearly-full)';
      case 'Full': return 'var(--status-full)';
      default: return 'var(--status-unknown)';
    }
  };

  // Quick jump blocks representing clustered adjacent hostels & towers
  const quickBlocks = [
    { id: 'stop-vit-mh-qrst', label: '🏢 MH Q-T (Kalam/Vajpayee)' },
    { id: 'stop-vit-mh-ghjkl', label: '🏠 MH G-L (Darling Mess)' },
    { id: 'stop-vit-mh-mnp', label: '🏠 MH M-P (Darwin/Patel)' },
    { id: 'stop-vit-mh-abcdef', label: '🏠 MH A-F (Einstein/Raman)' },
    { id: 'stop-vit-lh-abcdef', label: '🏡 LH A-F (Food Park)' },
    { id: 'stop-vit-lh-ghj', label: '🏡 LH G-J & RGT' },
    { id: 'stop-vit-tt', label: '🏢 Tech Tower (TT)' },
    { id: 'stop-vit-sjt', label: '🏛️ SJT Block' },
    { id: 'stop-vit-mb', label: '📚 MGR / Library' },
    { id: 'stop-vit-gate', label: '🚪 Main Gate 1' },
  ];

  // Flattened block directory for full search
  const allBlocksList = Object.entries(activeDirectory).flatMap(([clusterId, cluster]) =>
    Array.isArray(cluster?.blocks)
      ? cluster.blocks.map(b => ({ ...b, clusterName: cluster.cluster_name, clusterId }))
      : []
  );

  const filteredBlocks = (allBlocksList || []).filter(b =>
    (b?.code || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (b?.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (b?.phone || '').includes(searchQuery)
  );

  return (
    <div className="student-grid">
      {/* Left Column: ETA, Distance, & Boarding Cards */}
      <div className="student-sidebar">
        {/* Quick Block Jumpers Bar */}
        <div style={{ marginBottom: '12px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
            <span style={{ fontSize: '0.74rem', color: '#94a3b8', fontWeight: 700, textTransform: 'uppercase' }}>
              Quick Campus Block Jump:
            </span>
            <button
              onClick={() => setShowFullDirectory(!showFullDirectory)}
              style={{
                background: 'transparent',
                border: 'none',
                color: '#38bdf8',
                fontSize: '0.74rem',
                fontWeight: 700,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '4px'
              }}
            >
              <Phone size={11} />
              <span>{showFullDirectory ? 'Hide Directory' : 'All Block Contacts'}</span>
            </button>
          </div>

          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
            {quickBlocks.map((b) => (
              <button
                key={b.id}
                onClick={() => onSelectStop(b.id)}
                style={{
                  background: selectedStopId === b.id ? '#2563eb' : 'rgba(255, 255, 255, 0.06)',
                  border: `1px solid ${selectedStopId === b.id ? '#60a5fa' : 'rgba(255, 255, 255, 0.12)'}`,
                  color: '#ffffff',
                  fontSize: '0.73rem',
                  fontWeight: 600,
                  padding: '4px 8px',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  transition: 'all 0.15s'
                }}
              >
                {b.label}
              </button>
            ))}
          </div>
        </div>

        {/* Full Hostel Directory Modal / Drawer if toggled */}
        {showFullDirectory && (
          <div className="glass-panel" style={{ padding: '16px', marginBottom: '16px', background: 'rgba(15, 23, 42, 0.96)', border: '1px solid #38bdf8' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
              <div style={{ fontWeight: 800, fontSize: '0.92rem', color: '#fff', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <BookOpen size={16} color="#38bdf8" />
                <span>VIT Vellore Official Hostel Directory</span>
              </div>
              <button
                onClick={() => setShowFullDirectory(false)}
                style={{ background: 'transparent', border: 'none', color: '#94a3b8', cursor: 'pointer', fontSize: '0.8rem' }}
              >
                ✕
              </button>
            </div>

            <div style={{ position: 'relative', marginBottom: '10px' }}>
              <Search size={14} style={{ position: 'absolute', left: '10px', top: '10px', color: '#94a3b8' }} />
              <input
                type="text"
                placeholder="Search by block (e.g. MH Q, Kalam, LH A, 2548)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  width: '100%',
                  padding: '8px 10px 8px 32px',
                  borderRadius: '6px',
                  border: '1px solid rgba(255,255,255,0.2)',
                  background: 'rgba(0,0,0,0.4)',
                  color: '#fff',
                  fontSize: '0.8rem'
                }}
              />
            </div>

            <div style={{ maxHeight: '240px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '6px' }}>
              {filteredBlocks.map((blk) => (
                <div key={blk.code} style={{
                  background: 'rgba(255,255,255,0.04)',
                  padding: '8px 10px',
                  borderRadius: '6px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  fontSize: '0.78rem'
                }}>
                  <div>
                    <strong style={{ color: '#38bdf8' }}>{blk.code}</strong> — <span style={{ color: '#e2e8f0' }}>{blk.name}</span>
                  </div>
                  <div style={{ display: 'flex', gap: '8px' }}>
                    <a href={`tel:${blk.phone.replace(/\s+/g, '')}`} style={{ color: '#10b981', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '3px' }}>
                      <Phone size={11} /> {blk.phone}
                    </a>
                    {blk.email && (
                      <a href={`mailto:${blk.email}`} style={{ color: '#a855f7', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '3px' }}>
                        <Mail size={11} />
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Origin / Destination Selector */}
        <div className="glass-panel" style={{ padding: '18px', marginBottom: '16px' }}>
          <div className="stop-select-group">
            <label className="stop-label">
              <MapPin size={13} style={{ display: 'inline', marginRight: '4px', color: '#38bdf8' }} />
              Boarding Block (Origin Stop)
            </label>
            <select
              className="stop-dropdown"
              value={selectedStopId}
              onChange={(e) => onSelectStop(e.target.value)}
            >
              {stops.map((stop, idx) => (
                <option key={stop.id} value={stop.id}>
                  {idx + 1}. {stop.name}
                </option>
              ))}
            </select>
          </div>

          <div className="stop-select-group" style={{ marginBottom: '12px' }}>
            <label className="stop-label">
              <ArrowRight size={13} style={{ display: 'inline', marginRight: '4px', color: '#10b981' }} />
              To Destination Block
            </label>
            <select
              className="stop-dropdown"
              value={destStopId}
              onChange={(e) => setDestStopId(e.target.value)}
            >
              {stops.filter(s => s.id !== selectedStopId).map((stop) => (
                <option key={stop.id} value={stop.id}>
                  {stop.name}
                </option>
              ))}
            </select>
          </div>

          {/* Inter-block Distance Metric */}
          {journeyInfo && (
            <div style={{
              background: 'rgba(56, 189, 248, 0.08)',
              border: '1px solid rgba(56, 189, 248, 0.25)',
              borderRadius: '8px',
              padding: '10px 12px',
              fontSize: '0.8rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#38bdf8', fontWeight: 600 }}>
                <Navigation size={14} />
                <span>Inter-Block Distance: <strong>{journeyInfo.formatted}</strong></span>
              </div>
              <div style={{ fontSize: '0.72rem', color: '#94a3b8' }}>
                Walk: ~{journeyInfo.walkMins}m • Shuttle: ~{journeyInfo.shuttleMins}m
              </div>
            </div>
          )}

          {/* Hostel Blocks Directory for the current stop */}
          {currentCluster && (
            <div style={{
              marginTop: '12px',
              background: 'rgba(255, 255, 255, 0.03)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              borderRadius: '8px',
              padding: '10px 12px'
            }}>
              <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#38bdf8', marginBottom: '6px', display: 'flex', alignItems: 'center', gap: '5px' }}>
                <Phone size={12} />
                <span>Blocks at this Stop & Landline Contacts:</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                {currentCluster.blocks.map(b => (
                  <div key={b.code} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.74rem' }}>
                    <span style={{ color: '#cbd5e1' }}><strong>{b.code}</strong> ({b.name.split(' ')[0]})</span>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <a href={`tel:${b.phone.replace(/\s+/g, '')}`} style={{ color: '#10b981', textDecoration: 'none' }}>
                        📞 {b.phone}
                      </a>
                      <a href={`mailto:${b.email}`} style={{ color: '#94a3b8', textDecoration: 'none' }} title={b.email}>
                        ✉️
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {arrivalsData?.queue_demand !== undefined && (
            <div style={{ marginTop: '10px', fontSize: '0.8rem', color: '#94a3b8', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Users size={14} color="#38bdf8" />
              <span>Waiting queue at this stop: <strong style={{ color: '#fff' }}>{arrivalsData.queue_demand} students</strong></span>
            </div>
          )}
        </div>

        {/* Scan QR to Board Shuttle (₹20 Fare) Callout */}
        <div style={{
          background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.15) 0%, rgba(5, 150, 105, 0.12) 100%)',
          border: '1px solid rgba(16, 185, 129, 0.35)',
          borderRadius: '12px',
          padding: '12px 16px',
          marginBottom: '16px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '12px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: '#10b981', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', boxShadow: '0 2px 8px rgba(16, 185, 129, 0.35)' }}>
              <QrCode size={18} />
            </div>
            <div>
              <div style={{ fontSize: '0.86rem', fontWeight: 800, color: '#f8fafc' }}>
                Boarding Shuttle? Scan QR
              </div>
              <div style={{ fontSize: '0.74rem', color: '#cbd5e1' }}>
                ₹20 per turn • 24 hrs to pay before daily penalty
              </div>
            </div>
          </div>
          <button
            onClick={() => onOpenPayment && onOpenPayment()}
            style={{
              padding: '7px 12px',
              background: '#10b981',
              border: 'none',
              borderRadius: '8px',
              color: '#fff',
              fontSize: '0.78rem',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              whiteSpace: 'nowrap'
            }}
          >
            <span>Scan & Pay</span>
            <ArrowRight size={13} />
          </button>
        </div>

        {/* Primary Upcoming Dedicated Shuttle */}
        {primaryArrival ? (
          <div className={`eta-card ${primaryArrival.is_stale ? 'is-stale' : ''}`}>
            <div className="eta-header">
              <div className="shuttle-title">
                <span style={{ fontSize: '1.2rem' }}>🚌</span>
                <span>{primaryArrival.vehicle_label}</span>
              </div>
              <span className={`crowd-badge ${getBadgeClass(primaryArrival.occupancy_category)}`}>
                {primaryArrival.occupancy_category}
              </span>
            </div>

            {/* Live ETA and Real-time Shuttle Proximity Distance */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', margin: '10px 0' }}>
              <div className="eta-timer-wrap" style={{ margin: 0 }}>
                <div className="eta-big" style={{ color: primaryArrival.is_stale ? '#ec4899' : '#ffffff' }}>
                  {primaryArrival.eta_formatted}
                </div>
                <div className="eta-unit">
                  {primaryArrival.eta_formatted !== 'Unavailable' && primaryArrival.eta_formatted !== 'Arriving' ? 'ETA' : ''}
                </div>
              </div>

              {/* Shuttle Distance Badge */}
              <div style={{
                background: 'rgba(59, 130, 246, 0.18)',
                border: '1px solid rgba(59, 130, 246, 0.4)',
                borderRadius: '6px',
                padding: '4px 10px',
                textAlign: 'right'
              }}>
                <div style={{ fontSize: '0.7rem', color: '#94a3b8', textTransform: 'uppercase', fontWeight: 700 }}>
                  Live Distance
                </div>
                <div style={{ fontSize: '0.92rem', fontWeight: 800, color: '#38bdf8' }}>
                  📍 {primaryArrival.distance_formatted || 'Nearby'}
                </div>
              </div>
            </div>

            {/* Freshness & Driver Info */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px', flexWrap: 'wrap', gap: '6px' }}>
              <span className={`freshness-tag ${primaryArrival.is_stale ? 'stale-warning' : ''}`}>
                <Clock size={12} />
                {primaryArrival.is_stale
                  ? `Stale GPS (${Math.round(primaryArrival.freshness_seconds)}s ago)`
                  : `GPS verified ${Math.round(primaryArrival.freshness_seconds)}s ago`}
              </span>
              <span style={{ fontSize: '0.75rem', color: '#38bdf8', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '4px' }}>
                👨‍✈️ Driver: <strong>{primaryArrival.driver_name || 'Rajesh Kumar'}</strong>
                <span style={{ fontSize: '0.68rem', background: primaryArrival.is_driver_on_duty ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)', color: primaryArrival.is_driver_on_duty ? '#10b981' : '#ef4444', padding: '1px 5px', borderRadius: '4px', fontWeight: 700 }}>
                  {primaryArrival.is_driver_on_duty ? 'On-Duty' : 'Off-Duty'}
                </span>
              </span>
            </div>

            {/* Capacity Meter */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.78rem', color: '#cbd5e1' }}>
                <span>Seats Occupied: {primaryArrival.occupancy_count} / {primaryArrival.capacity}</span>
                <span><strong>{primaryArrival.available_seats}</strong> free seats left</span>
              </div>
              <div className="seat-meter">
                <div
                  className="seat-fill"
                  style={{
                    width: `${Math.min(100, (primaryArrival.occupancy_count / primaryArrival.capacity) * 100)}%`,
                    backgroundColor: getMeterColor(primaryArrival.occupancy_category)
                  }}
                />
              </div>
            </div>

            {/* Opt-in Boarding Intent Button (FR-08) */}
            <div className="intent-action-box">
              <button
                className="btn-intent"
                disabled={hasCheckedIn}
                onClick={() => onCheckIn(selectedStop.id)}
              >
                {hasCheckedIn ? (
                  <>
                    <CheckCircle2 size={16} />
                    <span>Intent Logged • You are in queue</span>
                  </>
                ) : (
                  <>
                    <Users size={16} />
                    <span>I Intend to Board This Shuttle</span>
                  </>
                )}
              </button>
              <div style={{ fontSize: '0.72rem', color: '#94a3b8', marginTop: '6px' }}>
                Signals student transport office to dispatch extra shuttles if demand exceeds capacity.
              </div>
            </div>
          </div>
        ) : (
          <div className="glass-panel" style={{ padding: '30px', textAlign: 'center', color: '#94a3b8' }}>
            <AlertCircle size={32} style={{ margin: '0 auto 10px', color: '#f59e0b' }} />
            <p>No active shuttles currently approaching this campus block.</p>
          </div>
        )}

        {/* Alternate Shuttle Card */}
        {alternateArrival && (
          <div className="eta-card alternate">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#818cf8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                {primaryArrival?.occupancy_category === 'Full' ? '⚠️ Recommended Alternative Shuttle' : 'Next Subsequent Shuttle'}
              </span>
              <span className={`crowd-badge ${getBadgeClass(alternateArrival.occupancy_category)}`}>
                {alternateArrival.occupancy_category}
              </span>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: '0.95rem', color: '#fff' }}>
                  {alternateArrival.vehicle_label}
                </div>
                <div style={{ fontSize: '0.78rem', color: '#94a3b8' }}>
                  📍 {alternateArrival.distance_formatted} • {alternateArrival.available_seats} seats free
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: 'var(--font-heading)', fontSize: '1.4rem', fontWeight: 800, color: '#38bdf8' }}>
                  {alternateArrival.eta_formatted}
                </div>
                <div style={{ fontSize: '0.7rem', color: '#64748b' }}>
                  {alternateArrival.is_stale ? 'GPS stale' : 'on track'}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Right Column: Campus Interactive Map */}
      <div className="student-map-col">
        <CampusMap
          stops={stops}
          vehicles={vehicles}
          selectedStopId={selectedStopId}
          onSelectStop={onSelectStop}
        />
      </div>
    </div>
  );
}
