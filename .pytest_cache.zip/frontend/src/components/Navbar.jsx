import React from 'react';
import { Bus, User, Gauge, ShieldAlert, BarChart3, Wifi, WifiOff, QrCode } from 'lucide-react';

export default function Navbar({ activeRole, onChangeRole, wsConnected, queueDemandTotal, pendingDuesCount }) {
  const tabs = [
    { id: 'student', label: 'Student Rider', icon: User },
    { id: 'payment', label: 'QR Scan & Pay (₹20)', icon: QrCode },
    { id: 'driver', label: 'Driver Console', icon: Gauge },
    { id: 'admin', label: 'Admin Fleet & Demand', icon: ShieldAlert },
    { id: 'analytics', label: 'Analytics & MAE', icon: BarChart3 },
  ];

  return (
    <header className="navbar">
      <div className="brand-section">
        <div className="brand-logo-icon">
          <Bus size={22} />
        </div>
        <div>
          <div className="brand-title">CampusMove AI</div>
          <div className="brand-subtitle">VIT Vellore Campus Transit & Demand Management</div>
        </div>

      </div>

      <div className="role-tabs">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              className={`tab-btn ${activeRole === tab.id ? 'active' : ''}`}
              onClick={() => onChangeRole(tab.id)}
            >
              <Icon size={16} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      <div className="nav-status">
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.8rem', color: '#94a3b8' }}>
          <div className={`connection-dot ${wsConnected ? '' : 'offline'}`} />
          <span>{wsConnected ? 'Live Feed' : 'Offline / Polling'}</span>
        </div>
      </div>
    </header>
  );
}
