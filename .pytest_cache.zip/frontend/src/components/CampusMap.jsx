import React, { useEffect, useRef } from 'react';
import L from 'leaflet';

export default function CampusMap({ stops, vehicles, selectedStopId, onSelectStop }) {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef({});
  const polylineRef = useRef(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Center precisely on VIT Vellore Campus (Katpadi, Vellore)
    const vitVelloreCenter = [12.9720, 79.1610];

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: vitVelloreCenter,
        zoom: 16,
        zoomControl: true
      });

      // Standard OpenStreetMap tiles - Free, no watermark, shows real VIT Vellore campus!
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> | VIT Vellore',
        maxZoom: 19
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    return () => {
      // Cleanup
    };
  }, []);

  // Icon mapping for specific VIT Vellore hostel clusters & academic buildings
  const getStopIconDetails = (id, idx) => {
    if (id.includes('mh-qrst')) return { emoji: '🏢', label: 'MH Q,R,S,T (Kalam/Vajpayee)', bg: '#1d4ed8' };
    if (id.includes('mh-ghjkl')) return { emoji: '🏠', label: 'MH G-L (Darling Mess)', bg: '#2563eb' };
    if (id.includes('mh-mnp')) return { emoji: '🏠', label: 'MH M-P (Darwin/Patel)', bg: '#0284c7' };
    if (id.includes('mh-abcdef')) return { emoji: '🏠', label: 'MH A-F (Einstein/Raman)', bg: '#0369a1' };
    if (id.includes('lh-abcdef')) return { emoji: '🏡', label: 'LH A-F (Food Park)', bg: '#db2777' };
    if (id.includes('lh-ghj')) return { emoji: '🏡', label: 'LH G-J & RGT Towers', bg: '#be185d' };
    if (id.includes('tt')) return { emoji: '🏢', label: 'Tech Tower (TT)', bg: '#7c3aed' };
    if (id.includes('sjt')) return { emoji: '🏛️', label: 'SJT Block', bg: '#4f46e5' };
    if (id.includes('mb')) return { emoji: '📚', label: 'Dr. MGR Block / Library', bg: '#0891b2' };
    if (id.includes('gate')) return { emoji: '🚪', label: 'Main Gate 1', bg: '#047857' };
    return { emoji: '📍', label: `Stop ${idx + 1}`, bg: '#1e293b' };
  };

  // Render / update stops and route loop
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !stops || stops.length === 0) return;

    // Draw route polyline connecting all VIT Vellore stops
    const latLngs = stops.map(s => [s.latitude, s.longitude]);
    if (stops.length > 2) {
      latLngs.push([stops[0].latitude, stops[0].longitude]);
    }

    if (polylineRef.current) {
      polylineRef.current.setLatLngs(latLngs);
    } else {
      polylineRef.current = L.polyline(latLngs, {
        color: '#2563eb',
        weight: 5,
        opacity: 0.85,
        dashArray: '10, 8'
      }).addTo(map);
    }

    // Stop markers
    stops.forEach((stop, idx) => {
      const isSelected = stop.id === selectedStopId;
      const markerKey = `stop-${stop.id}`;
      const iconInfo = getStopIconDetails(stop.id, idx);

      const stopHtml = `
        <div style="
          display: flex;
          flex-direction: column;
          align-items: center;
          cursor: pointer;
        ">
          <div style="
            width: ${isSelected ? '38px' : '32px'};
            height: ${isSelected ? '38px' : '32px'};
            border-radius: 50%;
            background: ${isSelected ? '#ffffff' : iconInfo.bg};
            border: 3px solid ${isSelected ? '#3b82f6' : '#ffffff'};
            color: ${isSelected ? '#3b82f6' : '#ffffff'};
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: ${isSelected ? '18px' : '14px'};
            box-shadow: 0 4px 14px rgba(0,0,0,0.4);
            transition: all 0.2s ease;
          ">
            ${iconInfo.emoji}
          </div>
          <div style="
            background: ${isSelected ? '#1e3a8a' : 'rgba(15, 23, 42, 0.94)'};
            border: 1px solid ${isSelected ? '#60a5fa' : 'rgba(255, 255, 255, 0.25)'};
            color: #ffffff;
            font-size: 10px;
            font-weight: 700;
            padding: 2px 6px;
            border-radius: 4px;
            margin-top: 2px;
            white-space: nowrap;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
          ">
            ${iconInfo.label}
          </div>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'custom-vit-stop-icon',
        html: stopHtml,
        iconSize: [52, 56],
        iconAnchor: [26, 28]
      });

      if (markersRef.current[markerKey]) {
        markersRef.current[markerKey].setIcon(customIcon);
        markersRef.current[markerKey].setLatLng([stop.latitude, stop.longitude]);
      } else {
        const marker = L.marker([stop.latitude, stop.longitude], { icon: customIcon })
          .addTo(map)
          .bindPopup(`
            <div style="font-family: sans-serif; padding: 4px;">
              <strong style="font-size: 13px; color: #1e3a8a;">${iconInfo.emoji} ${stop.name}</strong><br>
              <span style="font-size: 11px; color: #475569;">VIT Vellore Shuttle Stop #${idx + 1}</span><br>
              <button style="margin-top: 6px; padding: 4px 8px; background: #2563eb; color: white; border: none; border-radius: 4px; font-size: 11px; cursor: pointer;">
                Select this stop
              </button>
            </div>
          `);

        marker.on('click', () => {
          if (onSelectStop) onSelectStop(stop.id);
        });

        markersRef.current[markerKey] = marker;
      }
    });
  }, [stops, selectedStopId]);

  // Render / update moving shuttles with direction & status
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !vehicles) return;

    vehicles.forEach((veh) => {
      const markerKey = `veh-${veh.trip_id || veh.vehicle_id}`;
      const isStale = veh.is_stale;
      const isFull = veh.crowd_category === 'Full';
      
      let busBg = '#2563eb';
      if (veh.vehicle_label?.includes("Ladies") || veh.vehicle_label?.includes("LH")) busBg = '#db2777';
      else if (veh.vehicle_label?.includes("Q-R-S-T") || veh.vehicle_label?.includes("MH")) busBg = '#0284c7';
      else if (veh.vehicle_label?.includes("SJT") || veh.vehicle_label?.includes("Academic")) busBg = '#7c3aed';
      if (isFull) busBg = '#ef4444';
      if (isStale) busBg = '#ec4899';

      const busHtml = `
        <div style="
          display: flex;
          flex-direction: column;
          align-items: center;
          cursor: pointer;
        ">
          <div style="
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: ${busBg};
            border: 2px solid #ffffff;
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.5);
            transform: rotate(${veh.bearing || 0}deg);
            transition: transform 0.4s ease;
          ">
            🚌
          </div>
          <div style="
            background: rgba(15, 23, 42, 0.95);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: #ffffff;
            font-size: 10px;
            font-weight: 800;
            padding: 2px 7px;
            border-radius: 4px;
            margin-top: 2px;
            white-space: nowrap;
            box-shadow: 0 2px 6px rgba(0,0,0,0.4);
          ">
            ${veh.vehicle_label ? veh.vehicle_label.split('(')[0].trim() : 'VIT Shuttle'}
          </div>
          <div style="
            font-size: 9px;
            color: ${veh.is_driver_on_duty === false ? '#f59e0b' : '#38bdf8'};
            font-weight: 700;
            background: rgba(0,0,0,0.75);
            padding: 1px 4px;
            border-radius: 3px;
            margin-top: 1px;
            display: flex;
            align-items: center;
            gap: 2px;
          ">
            ${veh.is_driver_on_duty === false ? '⏸️ Driver Off-Duty' : `👨‍✈️ ${veh.driver_name ? veh.driver_name.split(' ')[0] : 'Driver'}`} • ${veh.occupancy || 0}/${veh.capacity || 40}
          </div>
        </div>
      `;

      const busIcon = L.divIcon({
        className: 'custom-vit-bus-icon',
        html: busHtml,
        iconSize: [60, 75],
        iconAnchor: [30, 37]
      });

      if (markersRef.current[markerKey]) {
        markersRef.current[markerKey].setLatLng([veh.latitude, veh.longitude]);
        markersRef.current[markerKey].setIcon(busIcon);
      } else {
        const marker = L.marker([veh.latitude, veh.longitude], { icon: busIcon })
          .addTo(map)
          .bindPopup(`
            <div style="font-family: sans-serif; padding: 4px;">
              <strong style="color: #1e3a8a; font-size: 13px;">${veh.vehicle_label || 'VIT Shuttle'}</strong><br>
              <div style="margin: 4px 0; padding: 4px 6px; background: #f1f5f9; border-radius: 4px; font-size: 11px;">
                <b>👨‍✈️ Registered Driver:</b> ${veh.driver_name || 'Awaiting Registration'}<br>
                <b>Tracking Status:</b> ${veh.is_driver_on_duty === false ? '<span style="color:#ef4444;font-weight:bold;">OFF-DUTY (Standby)</span>' : '<span style="color:#10b981;font-weight:bold;">ON-DUTY (Live GPS Active)</span>'}
              </div>
              <b>Speed:</b> ${veh.speed_mps ? Math.round(veh.speed_mps * 3.6) : 22} km/h<br>
              <b>Occupancy:</b> ${veh.occupancy || 0} / ${veh.capacity || 40} passengers (${veh.available_seats || 0} free seats)
            </div>
          `);
        markersRef.current[markerKey] = marker;
      }
    });
  }, [vehicles]);

  return (
    <div className="map-container-wrap">
      <div ref={mapContainerRef} style={{ height: '100%', width: '100%' }} />
    </div>
  );
}
